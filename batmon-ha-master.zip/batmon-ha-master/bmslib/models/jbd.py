"""
JBD protocol references
https://github.com/syssi/esphome-jbd-bms
https://github.com/syssi/esphome-jbd-bms/blob/main/docs/Jiabaida.communication.protocol.pdf
https://gitlab.com/bms-tools/bms-tools/-/tree/master/bmstools?ref_type=heads
https://github.com/sshoecraft/jbdtool/blob/1168edac728d1e0bdea6cd4fa142548c445f80ec/main.c
https://github.com/Bangybug/esp32xiaoxiangble/blob/master/src/main.cpp


https://blog.ja-ke.tech/2020/02/07/ltt-power-bms-chinese-protocol.html # checksum
Unseen:
https://github.com/tgalarneau/bms

"""
import asyncio

from bmslib.bms import BmsSample
from bmslib.bt import BtBms


def _jbd_command(command: int):
    return bytes([0xDD, 0xA5, command, 0x00, 0xFF, 0xFF - (command - 1), 0x77])


def _validate_jbd_response(frame: bytes, expected_command: int = None) -> bytes:
    """Validate a complete JBD response and return its payload.

    Cell values are intentionally not range-checked here. A structurally valid
    frame reporting 0 mV may represent a real, safety-critical cell fault and
    must reach the caller unchanged.
    """
    if len(frame) < 7:
        raise ValueError("JBD response is shorter than the minimum frame size")
    if frame[0] != 0xDD:
        raise ValueError("JBD response has an invalid header")

    command = frame[1]
    if expected_command is not None and command != expected_command:
        raise ValueError(
            f"JBD response command mismatch: expected 0x{expected_command:02x}, "
            f"got 0x{command:02x}"
        )

    payload_length = frame[3]
    expected_length = payload_length + 7  # header(4) + checksum(2) + terminator(1)
    if len(frame) != expected_length:
        raise ValueError(
            f"JBD response length mismatch: expected {expected_length} bytes, "
            f"got {len(frame)}"
        )
    if frame[-1] != 0x77:
        raise ValueError("JBD response has an invalid terminator")
    if frame[2] != 0:
        raise ValueError(f"JBD command 0x{command:02x} failed with status 0x{frame[2]:02x}")

    received_checksum = int.from_bytes(frame[-3:-1], "big")
    calculated_checksum = (0x10000 - sum(frame[2:-3])) & 0xFFFF
    if received_checksum != calculated_checksum:
        raise ValueError(
            f"JBD response checksum mismatch: expected 0x{calculated_checksum:04x}, "
            f"got 0x{received_checksum:04x}"
        )

    return frame[4:-3]


class JbdBt(BtBms):
    UUID_RX = '0000ff01-0000-1000-8000-00805f9b34fb'
    UUID_TX = '0000ff02-0000-1000-8000-00805f9b34fb'
    TIMEOUT = 16

    def __init__(self, address, **kwargs):
        # newer JBD firmware gates the protocol behind a passkey pairing (#217)
        kwargs.setdefault('_uses_pin', True)
        super().__init__(address, **kwargs)
        self._buffer = bytearray()
        self._switches = None
        self._last_response = None

    def _notification_handler(self, sender, data):
        self._buffer += data

        while self._buffer:
            # Discard noise before the next JBD header, but retain a partial frame.
            header = self._buffer.find(0xDD)
            if header < 0:
                self.logger.warning("discarding %d bytes without a JBD header", len(self._buffer))
                self._buffer.clear()
                return
            if header:
                self.logger.warning("discarding %d bytes before JBD header", header)
                del self._buffer[:header]
            if len(self._buffer) < 4:
                return

            frame_length = self._buffer[3] + 7
            if len(self._buffer) < frame_length:
                return

            frame = bytes(self._buffer[:frame_length])
            del self._buffer[:frame_length]
            try:
                _validate_jbd_response(frame)
            except ValueError as exc:
                self.logger.warning("discarding invalid JBD response: %s", exc)
                continue

            command = frame[1]
            self._last_response = frame
            self._fetch_futures.set_result(command, frame)

    async def connect(self, **kwargs):
        await super().connect(**kwargs)
        #try:
        #    await super().connect(**kwargs)
        #except Exception as e:
        #    self.logger.info("normal connect failed (%s), connecting with scanner", e)
        #    await self._connect_with_scanner(**kwargs)

        await self.client.start_notify(self.UUID_RX, self._notification_handler)

    async def disconnect(self):
        await self.stop_notify(self.UUID_RX)
        await super().disconnect()

    async def _q(self, cmd):
        with self._fetch_futures.acquire(cmd):
            await self.client.write_gatt_char(self.UUID_TX, data=_jbd_command(cmd))
            return await self._fetch_futures.wait_for(cmd, self.TIMEOUT)

    async def fetch(self) -> BmsSample:
        # binary reading
        #  https://github.com/NeariX67/SmartBMSUtility/blob/main/Smart%20BMS%20Utility/Smart%20BMS%20Utility/BMSData.swift

        frame = await self._q(cmd=0x03)
        buf = _validate_jbd_response(frame, expected_command=0x03)

        num_cell = int.from_bytes(buf[21:22], 'big')
        num_temp = int.from_bytes(buf[22:23], 'big')

        # The NTC count byte must fit the payload. A frame that passes the
        # length and checksum check but declares more sensors than it carries
        # would otherwise decode empty slices to -273.1 C and make HA discovery
        # create one entity per phantom sensor (253 of them in #321).
        if len(buf) < 23 + num_temp * 2:
            raise ValueError(
                f"JBD basic-info declares {num_temp} NTC sensors but payload has "
                f"room for {(len(buf) - 23) // 2}"
            )

        mos_byte = int.from_bytes(buf[20:21], 'big')

        # JBD protection-status bitmask (header-stripped offset 16:18). Bits
        # cover cell OV/UV, pack OV/UV, charge/discharge OC, short-circuit,
        # NTC OT/UT, MOSFET errors, etc. We surface the raw code + a derived
        # "any alarm" boolean so HA can show a problem indicator.
        problem_code = int.from_bytes(buf[16:18], byteorder='big', signed=False)

        # Balance status: bytes 12-13 cells 1-16, bytes 14-15 cells 17-32, one
        # bit per cell, set while that cell is being bled (#283).
        balancing_cells = int.from_bytes(buf[12:14], 'big') | (int.from_bytes(buf[14:16], 'big') << 16)

        current = -int.from_bytes(buf[2:4], byteorder='big', signed=True) / 100
        charge = int.from_bytes(buf[4:6], byteorder='big', signed=False) / 100

        # `runtime` (estimated seconds-to-empty) is derived centrally by the
        # sampler from charge / smoothed discharge current, see
        # BtBms.estimate_runtime().
        sample = BmsSample(
            voltage=int.from_bytes(buf[0:2], byteorder='big', signed=False) / 100,
            current=current,

            charge=charge,
            capacity=int.from_bytes(buf[6:8], byteorder='big', signed=False) / 100,
            soc=buf[19],

            num_cycles=int.from_bytes(buf[8:10], byteorder='big', signed=False),

            temperatures=[(int.from_bytes(buf[23 + i * 2:i * 2 + 25], 'big') - 2731) / 10 for i in range(num_temp)],

            switches=dict(
                discharge=mos_byte == 2 or mos_byte == 3,
                charge=mos_byte == 1 or mos_byte == 3,
            ),

            problem_code=problem_code,
            balancing_cells=balancing_cells,

            # charge_enabled
            # discharge_enabled
        )

        self._switches = dict(sample.switches)

        # print(dict(num_cell=num_cell, num_temp=num_temp))

        # self.rawdat['P']=round(self.rawdat['Vbat']*self.rawdat['Ibat'], 1)

        product_date = int.from_bytes(buf[10:12], byteorder='big', signed=True)
        # productDate = convertByteToUInt16(data1: data[14], data2: data[15])

        return sample

    async def fetch_voltages(self):
        frame = await self._q(cmd=0x04)
        payload = _validate_jbd_response(frame, expected_command=0x04)
        if len(payload) % 2:
            raise ValueError(f"JBD cell-voltage payload has odd length {len(payload)}")
        return [int.from_bytes(payload[i:i + 2], 'big') for i in range(0, len(payload), 2)]

    async def set_switch(self, switch: str, state: bool):

        assert switch in {"charge", "discharge"}

        # see https://wiki.jmehan.com/download/attachments/59114595/JBD%20Protocol%20English%20version.pdf?version=1&modificationDate=1650716897000&api=v2
        #
        def jbd_checksum(cmd, data):
            crc = 0x10000
            for i in (data + bytes([len(data), cmd])):
                crc = crc - int(i)
            return crc.to_bytes(2, byteorder='big')

        def jbd_message(status_bit, cmd, data):
            return bytes([0xDD, status_bit, cmd, len(data)]) + data + jbd_checksum(cmd, data) + bytes([0x77])

        if not self._switches:
            await self.fetch()

        new_switches = {**self._switches, switch: state}
        switches_sum = sum(new_switches.values())
        if switches_sum == 2:
            tc = 0x00  # all on
        elif switches_sum == 0:
            tc = 0x03  # all off
        elif (switch == "charge" and not state) or (switch == "discharge" and state):
            tc = 0x01  # charge off
        else:
            tc = 0x02  # charge on, discharge off

        data = jbd_message(status_bit=0x5A, cmd=0xE1, data=bytes([0x00, tc]))  # all off
        self.logger.info("send switch msg: %s", data)
        await self.client.write_gatt_char(self.UUID_TX, data=data)

    def debug_data(self):
        return self._last_response


async def main():
    # mac_address = 'A3161184-6D54-4B9E-8849-E755F10CEE12'
    mac_address = 'A4:C1:38:44:48:E7'
    # serial_service = '0000ff00-0000-1000-8000-00805f9b34fb'

    bms = JbdBt(mac_address, name='jbd')
    await bms.connect()
    voltages = await bms.fetch_voltages()
    print(voltages)
    # sample = await bms.fetch()
    # print(sample)
    await bms.disconnect()


if __name__ == '__main__':
    asyncio.run(main())
